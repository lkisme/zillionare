import pkg_resources

__author__ = """Aaron Yang"""
__email__ = "code@jieyu.ai"
__version__ = pkg_resources.get_distribution("zillionare-omega").version

app_name = "omega"
