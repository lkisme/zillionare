#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
quotes fetcher
"""
import logging

logger = logging.getLogger(__file__)
